from dbtable import *

class DriversTable(DbTable):
    def table_name(self):
        return self.dbconn.prefix + "drivers"

    def columns(self):
        return {
            "id":         ["serial", "PRIMARY KEY"],
            "last_name":  ["varchar(64)", "NOT NULL"],
            "first_name": ["varchar(64)", "NOT NULL"],
            "birth_date": ["date", "NOT NULL"],
            "country_id": ["integer", "NOT NULL", "REFERENCES countries(id)"],
            "wins_count": ["integer", "NOT NULL", "DEFAULT 0", "CHECK (wins_count >= 0)"]
        }

    def primary_key(self):
        return ["id"]

    def all_by_country_id(self, cid):
        sql = """
            SELECT id, birth_date, country_id, first_name, last_name, wins_count
            FROM drivers
            WHERE country_id = %s
            ORDER BY last_name, first_name
        """
        cur = self.dbconn.conn.cursor()
        cur.execute(sql, (cid,))
        return cur.fetchall()