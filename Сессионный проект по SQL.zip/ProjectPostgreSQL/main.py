# ФИО: Федотов Александр Максимович
# вариант: 1
# условия задания варианта: Таблицы страны и гонщики без связей с другими таблицами. 
# Если страны не в отдельной таблице, то выделите их в отдельную таблицу.
import sys
sys.path.append('tables')

from project_config import *
from dbconnection import *
from countries_table import *
from drivers_table import *

class Main:

    config = ProjectConfig()
    connection = DbConnection(config)

    def __init__(self):
        DbTable.dbconn = self.connection
        return

    def db_init(self):
        ct = CountriesTable()
        dt = DriversTable()
        ct.create()
        dt.create()

    def db_insert_somethings(self):
        ct = CountriesTable()
        dt = DriversTable()

        ct.insert_one(["United Kingdom", "GBR"])
        ct.insert_one(["Germany", "DEU"])
        ct.insert_one(["Spain", "ESP"])

        dt.insert_one(["Hamilton", "Lewis", "1985-01-07", 1, 103])
        dt.insert_one(["Vettel", "Sebastian", "1987-07-03", 2, 53])
        dt.insert_one(["Alonso", "Fernando", "1981-07-29", 3, 32])

    def db_drop(self):
        dt = DriversTable()
        ct = CountriesTable()
        dt.drop()
        ct.drop()
        return

    def show_main_menu(self):
        menu = """Добро пожаловать! 
    Основное меню (выберите цифру в соответствии с необходимым действием): 
        1 - просмотр стран;
        2 - сброс и инициализация таблиц;
        9 - выход."""
        print(menu)

    def read_next_step(self):
        return input("=> ").strip()

    def after_main_menu(self, next_step):
        if next_step == "2":
            self.db_drop()
            self.db_init()
            self.db_insert_somethings()
            print("Таблицы созданы заново!")
            return "0"
        elif next_step != "1" and next_step != "9":
            print("Выбрано неверное число! Повторите ввод!")
            return "0"
        else:
            return next_step
            
    def show_countries(self):
        self.country_id = -1
        print("Просмотр списка стран!")
        print("№  Страна          Код")
        lst = CountriesTable().all()
        for idx, row in enumerate(lst, start=1):
            num = str(idx)
            name = row[2]
            code = row[0]
            print(f"{num:<2} {name:<15} {code}")
        menu = """Дальнейшие операции: 
        0 - возврат в главное меню;
        3 - добавление новой страны;
        4 - удаление страны;
        5 - просмотр гонщиков из страны;
        6 - изменение страны;
        9 - выход."""
        print(menu)
        return

    def after_show_countries(self, next_step):
        while True:
            if next_step == "3":
                self.show_add_country()          
                return "1"                      
            elif next_step == "4":
                self.delete_country()           
                return "1"
            elif next_step == "5":
                next_step = self.show_drivers_by_country()  
            elif next_step == "6":
                self.edit_country()
                return "1"
            elif next_step not in ("0", "9"):
                print("Выбрано неверное число! Повторите ввод!")
                return "1"
            else:
                return next_step


    def show_add_country(self):
        data = []

        name = input("Введите название страны (1 - отмена): ").strip()
        if name == "1":
            return
        while True:
            if len(name) == 0:
                name = input("Название не может быть пустым! Введите заново (1 - отмена): ").strip()
                if name == "1":
                    return
                continue
            if len(name) > 128:
                name = input("Слишком длинное название (макс 128 символов)! Введите заново (1 - отмена): ").strip()
                if name == "1":
                    return
                continue
            break
        data.append(name)

        code = input("Введите код страны (до 3 символов, Enter — пропустить, 1 - отмена): ").strip()
        if code == "1":
            return
        while len(code) > 3:
            code = input("Код не может быть длиннее 3 символов! Введите заново (1 - отмена): ").strip()
            if code == "1":
                return
        data.append(code if code != "" else None)

        CountriesTable().insert_one(data)

    def delete_country(self):
        lst = CountriesTable().all()
        if not lst:
            print("Список стран пуст.")
            return

        num = input("Укажите номер строки страны для удаления (0 - отмена): ").strip()
        if num == "0":
            return
        while not num.isdigit() or not (1 <= int(num) <= len(lst)):
            num = input("Неверный номер строки! Повторите ввод (0 - отмена): ").strip()
            if num == "0":
                return

        country = lst[int(num) - 1]
        try:
            country_id = country[1]
            CountriesTable().delete_by_id(country_id)
            print("Страна удалена.")
        except Exception:
            self.connection.conn.rollback()    
            print("Невозможно удалить страну: сначала удалите всех гонщиков этой страны.")
            return
        
    def edit_country(self):
        lst = CountriesTable().all()
        if not lst:
            print("Список стран пуст.")
            return

        num = input("Укажите номер строки страны для изменения (0 - отмена): ").strip()
        if num == "0":
            return
        while not num.isdigit() or not (1 <= int(num) <= len(lst)):
            num = input("Неверный номер строки! Повторите ввод (0 - отмена): ").strip()
            if num == "0":
                return

        country = lst[int(num) - 1]
        country_id = country[1]
        old_name = country[2]
        old_code = country[0]

        print(f"Текущие значения: название = '{old_name}', код = '{old_code}'")

        # Ввод нового name
        name = input(f"Введите новое название страны (Enter — оставить '{old_name}', 1 - отмена): ").strip()
        if name == "1":
            return
        if name == "":
            name = old_name
        while True:
            if len(name) == 0:
                name = input("Название не может быть пустым! Введите заново (1 - отмена): ").strip()
                if name == "1":
                    return
                if name == "":
                    name = old_name
                    break
                continue
            if len(name) > 128:
                name = input("Слишком длинное название (макс 128 символов)! Введите заново (1 - отмена): ").strip()
                if name == "1":
                    return
                if name == "":
                    name = old_name
                    break
                continue
            break

        # Ввод нового code
        code = input(f"Введите новый код страны (до 3 символов, Enter — оставить '{old_code}', 1 - отмена): ").strip()
        if code == "1":
            return
        if code == "":
            code = old_code
        while code is not None and len(code) > 3:
            code = input("Код не может быть длиннее 3 символов! Введите заново (Enter — оставить старый, 1 - отмена): ").strip()
            if code == "1":
                return
            if code == "":
                code = old_code
                break

        data = [name, code]
        try: 
            CountriesTable().update_by_id(country_id, data)
            print("Страна изменена.")
        except Exception:
            self.connection.conn.rollback()
            print("Ошибка при изменении страны (проверьте данные).")
            return

    def show_drivers_by_country(self):
        if getattr(self, "country_id", -1) == -1:
            while True:
                num = input("Укажите номер строки со страной (0 - отмена): ").strip()
                if num == "0":
                    return "1"
                if not num.isdigit():
                    print("Нужно ввести номер строки!")
                    continue
                country = CountriesTable().find_by_position(int(num))
                if not country:
                    print("Нет страны с таким номером строки!")
                else:
                    self.country_id = country[1]    
                    self.country_obj = country      
                    break

        print(f"Выбрана страна: {self.country_obj[2]}")
        print("Гонщики:")

        lst = DriversTable().all_by_country_id(self.country_id)
        for idx, row in enumerate(lst, start=1):
            print(f"{idx}\t{row[3]} {row[4]}\tпобед: {row[5]}")

        menu = """Дальнейшие операции:
        0 - возврат в главное меню;
        1 - возврат в просмотр стран;
        6 - добавление нового гонщика;
        7 - удаление гонщика;
        9 - выход."""
        print(menu)
        next_step = self.read_next_step()
    
        while True:
            if next_step == "6":
                self.show_add_driver()
                return "5"          # вернуться к просмотру гонщиков
            elif next_step == "7":
                self.delete_driver()
                return "5"
            elif next_step in ("0", "1", "9"):
                return next_step
            else:
                print("Выбрано неверное число! Повторите ввод!")
                next_step = self.read_next_step()

    def show_add_driver(self):
        data = []

        last_name = input("Введите фамилию гонщика (1 - отмена): ").strip()
        if last_name == "1":
            return
        while len(last_name) == 0 or len(last_name) > 128:
            last_name = input("Фамилия не может быть пустой и длиннее 128 символов! Введите заново (1 - отмена): ").strip()
            if last_name == "1":
                return
        data.append(last_name)

        first_name = input("Введите имя гонщика (1 - отмена): ").strip()
        if first_name == "1":
            return
        while len(first_name) == 0 or len(first_name) > 128:
            first_name = input("Имя не может быть пустым и длиннее 128 символов! Введите заново (1 - отмена): ").strip()
            if first_name == "1":
                return
        data.append(first_name)

        birth = input("Введите дату рождения в формате ГГГГ-ММ-ДД (1 - отмена): ").strip()
        if birth == "1":
            return
        while len(birth) != 10 or birth[4] != "-" or birth[7] != "-":
            birth = input("Неверный формат даты! Введите дату в формате ГГГГ-ММ-ДД (1 - отмена): ").strip()
            if birth == "1":
                return
        data.append(birth)

        data.append(self.country_id)

        wins = input("Введите количество побед (целое число, 0 - если нет, 1 - отмена): ").strip()
        if wins == "1":
            return
        while not wins.isdigit():
            wins = input("Нужно ввести неотрицательное целое число! Повторите ввод (1 - отмена): ").strip()
            if wins == "1":
                return
        data.append(int(wins))

        try:
            DriversTable().insert_one(data)
            print("Гонщик добавлен.")
        except Exception:
            self.connection.conn.rollback()
            print("Ошибка при добавлении гонщика (проверьте данные).")
            return  

    def delete_driver(self):
        lst = DriversTable().all_by_country_id(self.country_id)
        if not lst:
            print("Для этой страны нет гонщиков.")
            return

        num = input("Укажите номер строки гонщика для удаления (0 - отмена): ").strip()
        if num == "0":
            return
        while not num.isdigit() or not (1 <= int(num) <= len(lst)):
            num = input("Неверный номер строки! Повторите ввод (0 - отмена): ").strip()
            if num == "0":
                return
            
        driver = lst[int(num) - 1]
        driver_id = driver[0]
        try: 
            DriversTable().delete_by_id(driver_id)
            print("Гонщик удалён.")
        except Exception:
            self.connection.conn.rollback()
            print("Невозможно удалить гонщика (ошибка БД).")
            return

    def main_cycle(self):
        current_menu = "0"
        next_step = None
        while current_menu != "9":
            if current_menu == "0":
                self.show_main_menu()
                next_step = self.read_next_step()
                current_menu = self.after_main_menu(next_step)

            elif current_menu == "1":
                self.show_countries()
                next_step = self.read_next_step()
                current_menu = self.after_show_countries(next_step)

            elif current_menu == "3":
                self.show_add_country()
                current_menu = "1"

        print("До свидания!")
        return


    def test(self):
        DbTable.dbconn.test()

m = Main()
# Откоментируйте эту строку и закоментируйте следующую для теста
# соединения с БД
# m.test()
m.main_cycle()
    
